﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReverseString
{
    class ReverseString
    {
        static void Main()
        {
            string input = Console.ReadLine();
            string output = string.Join("", input.Reverse());
            Console.WriteLine(output);
        }
    }
}
