﻿namespace o
{
    public class category
    {
        public int Id { get; set; }
        
        public string NAME { get; set; }

        public string Description { get; set; }
    }
}
