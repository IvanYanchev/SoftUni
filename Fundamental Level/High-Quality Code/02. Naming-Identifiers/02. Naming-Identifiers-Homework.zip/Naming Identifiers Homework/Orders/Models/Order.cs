﻿namespace o
{
    public class order
    {
        public int ID { get; set; }

        public int product_id { get; set; }

        public int quant { get; set; }

        public decimal Discount { get; set; }
    }
}
