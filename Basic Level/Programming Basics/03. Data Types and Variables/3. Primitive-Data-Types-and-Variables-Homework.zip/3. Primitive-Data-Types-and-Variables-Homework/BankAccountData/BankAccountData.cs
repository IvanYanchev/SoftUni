﻿using System;

class BankAccountData
{
    static void Main()
    {
        string firstName = "Ivan";
        string middleName = "Ivanov";
        string lastName = "Dimitrov";
        decimal accountBalance = 3546.67m;
        string bankName = "National Bank";
        string iban = "GB82 WEST 1234 5698 7654 32";
        ulong creditCardNumber1 = 4916761378233193L;
        ulong creditCardNumber2 = 5122693651469219L;
        ulong creditCardNumber3 = 376704804629072L;
    }
}