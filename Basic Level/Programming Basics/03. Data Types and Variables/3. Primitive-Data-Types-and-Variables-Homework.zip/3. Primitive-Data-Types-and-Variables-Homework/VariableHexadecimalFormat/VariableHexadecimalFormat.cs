﻿using System;

class VariableHexadecimalFormat
{
    static void Main()
    {
        int myValue = 0xFE;
        Console.WriteLine(myValue);
    }
}
