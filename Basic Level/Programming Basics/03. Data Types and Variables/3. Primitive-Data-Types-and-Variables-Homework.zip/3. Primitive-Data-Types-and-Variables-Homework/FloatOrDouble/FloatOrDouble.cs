﻿using System;

class FloatOrDouble
{
    static void Main(string[] args)
    {
        double variable1 = 34.567839023;
        float variable2 = 12.345f;
        double variable3 = 8923.1234857;
        float variable4 = 3456.091f;
        Console.WriteLine(variable1);
        Console.WriteLine(variable2);
        Console.WriteLine(variable3);
        Console.WriteLine(variable4);
    }
}
