﻿using System;

class DeclareVariables
{
    static void Main(string[] args)
    {
        ushort varibleUShort = 52130;
        sbyte variableSByte = -115;
        uint variableUInt = 4825932;
        byte variableByte = 97;
        short variableShort = -10000;
        Console.WriteLine(varibleUShort);
        Console.WriteLine(variableSByte);
        Console.WriteLine(variableUInt);
        Console.WriteLine(variableByte);
        Console.WriteLine(variableShort);
    }
}
