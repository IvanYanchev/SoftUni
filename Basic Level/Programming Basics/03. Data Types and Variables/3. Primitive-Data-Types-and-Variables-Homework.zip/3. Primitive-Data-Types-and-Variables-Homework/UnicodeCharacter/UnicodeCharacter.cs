﻿using System;

class UnicodeCharacter
{
    static void Main()
    {
        char myChar = '\u002a';
        Console.WriteLine(myChar);
    }
}